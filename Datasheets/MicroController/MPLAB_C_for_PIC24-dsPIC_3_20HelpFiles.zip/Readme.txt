Help files for MPLAB C for PIC24/dsPIC v3.20

These files should be copied to the C30 installation folder and the �docs� subdirectory.

